
import java.sql.*;

public class mydbcon{
    public Connection c;
    public Statement s;


    mydbcon(){
        
        try{
            // Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");


            String url = "jdbc:sqlserver://DESKTOP-VMKV8DA;databaseName=dataman;encrypt=false;trustServerCertificate=true";
            c = DriverManager.getConnection(
                url, "sa", "1234"
                
            );
            s = c.createStatement();

            System.out.println("Connection Successful");

            
        }catch(Exception e){
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {
        new mydbcon();
    }
}