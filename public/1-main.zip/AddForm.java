import javax.swing.*;

import com.toedter.calendar.JDateChooser;

import net.proteanit.sql.DbUtils;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Calendar;



public class AddForm extends JFrame implements ActionListener{

     JTextField fname,fage,fmob,faddress,fstate,fcountry;
    JDateChooser fdob, fdoj;
     JComboBox<String> fcity;
      JTable table;
    JButton submit,details,edit;

    int editEmpId;

    public void AddAge(JDateChooser ffdob,JDateChooser ffdoj, JTextField ffage){
        Calendar dob = ffdob.getCalendar();
        Calendar doj = ffdoj.getCalendar();
         if (dob == null || doj == null) {
        return;
        }
        int age = doj.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
        ffage.setText(Integer.toString(age));
    
    }

    private boolean validateForm() {

    if (fname.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Enter Name ");
        fname.requestFocus();
        return false;
    }

    if (fdob.getDate() == null) {
        JOptionPane.showMessageDialog(this, "Enter DOB");
        fdob.requestFocus();
        return false;
    }

    if (fdoj.getDate() == null) {
        JOptionPane.showMessageDialog(this, "Enter DOJ");
        fdoj.requestFocus();
        return false;
    }

    if (fmob.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Enter Mobile Number");
        fmob.requestFocus();
        return false;
    }

    if (!fmob.getText().matches("\\d{10}")) {
        JOptionPane.showMessageDialog(this, "Enter 10 digit Mobile number");
        fmob.requestFocus();
        return false;
    }

    if (fcity.getSelectedIndex() == 0) {
        JOptionPane.showMessageDialog(this, "Please select a city");
        fcity.requestFocus();
        return false;
    }

    return true; 
}


    public AddForm(int empId){
        this(); 

        try{
            int cityId = 0;
            mydbcon c1 = new mydbcon();
            ResultSet rs = c1.s.executeQuery("select emp_name, dob,doj,mobile,address, cityid from employee where emp_id= '"+empId+"'");

            while(rs.next()){
            fname.setText(rs.getString("emp_name"));
            fdob.setDate(rs.getDate("dob"));
            fdoj.setDate(rs.getDate("doj"));
            fmob.setText(rs.getString("mobile"));
            faddress.setText(rs.getString("address"));
            cityId = rs.getInt("cityid");
            }
            ResultSet rs2 = c1.s.executeQuery("select city_name from city where city_id= '"+cityId+"'");
            if (rs2.next()) {
            fcity.setSelectedItem(rs2.getString("city_name"));
            }
            ResultSet rs3 = c1.s.executeQuery("select class, college, obtain, total from education where empid= '"+empId+"'");

            int row = 0;
            while (rs3.next() && row < 3) {
                table.setValueAt(rs3.getString("class"), row, 0);
                table.setValueAt(rs3.getString("college"), row, 1);
                table.setValueAt(String.valueOf(rs3.getFloat("obtain")), row, 2);
                table.setValueAt(String.valueOf(rs3.getFloat("total")), row, 3);
                row++;
            }

        }catch(Exception e){
            e.printStackTrace();
        }

    }
    

    AddForm(int empId, String mode){
        editEmpId = empId;
        this(empId); 
        if(mode == "read"){
            submit.setVisible(false);
            edit.setVisible(false);
        }
        else if(mode == "edit"){
            submit.setVisible(false);
            edit.setVisible(true);
        }
    }

    public AddForm() {
         setSize(900, 900);
        setLayout(null);

        details = new JButton("List of Students");
        details.addActionListener(this);
        details.setBounds(350, 60, 500  , 30);
        add(details);

        JLabel heading = new JLabel("STUDENT REGISTRATION");
        heading.setBounds(350, 80, 500  , 100);
        add(heading);

        JLabel name = new JLabel("NAME");
        name.setBounds(250, 150, 500  , 30);
        add(name);
            
        fname = new JTextField();
        fname.setBounds(350, 150, 500  , 30);
        add(fname);

        JLabel dob = new JLabel("Date of Birth");
        dob.setBounds(250, 200, 500  , 30);
        add(dob);
            
        fdob = new JDateChooser();
        fdob.setBounds(350, 200, 500  , 30);
        add(fdob);

        JLabel doj = new JLabel("Date of Joining");
        doj.setBounds(250, 250, 500  , 30);
        add(doj);
            
         fdoj = new JDateChooser();
        fdoj.setBounds(350, 250, 500  , 30);
        add(fdoj);

         JLabel age = new JLabel("AGE");
        age.setBounds(250, 300, 500  , 30);
        add(age);
            
         fage = new JTextField();
        fage.setBounds(350, 300, 500  , 30);
        fage.setEnabled(false);
        add(fage);

        fdob.addPropertyChangeListener("date", e->AddAge(fdob, fdoj, fage));
        fdoj.addPropertyChangeListener("date", e->AddAge(fdob, fdoj, fage));
   
        JLabel mob = new JLabel("MOBILE NO");
        mob.setBounds(250, 350, 500  , 30);
        add(mob);
            
         fmob = new JTextField();
        fmob.setBounds(350, 350, 500  , 30);
        add(fmob);

         JLabel address = new JLabel("ADDRESS");
        address.setBounds(250, 400, 500  , 30);
        add(address);
            
         faddress = new JTextField();
        faddress.setBounds(350, 400, 500  , 30);
        add(faddress);


        JLabel city = new JLabel("CITY");
        city.setBounds(250, 450, 500  , 30);
        add(city);
            
         fcity = new JComboBox();
        fcity.setBounds(350, 450, 500  , 30);
        fcity.addItem("<Select City>");
        add(fcity);

        JLabel state = new JLabel("STATE");
        state.setBounds(250, 500, 500  , 30);
        add(state);
            
         fstate = new JTextField();
        fstate.setBounds(350, 500, 500  , 30);
        add(fstate);

        JLabel country = new JLabel("COUNTRY");
        country.setBounds(250, 550, 500  , 30);
        add(country);
            
         fcountry = new JTextField();
        fcountry.setBounds(350, 550, 500  , 30);
        add(fcountry);

        try{
            mydbcon c1 = new mydbcon();
           ResultSet s =  c1.s.executeQuery("select city_name from city");
            while(s.next()){
                fcity.addItem(s.getString("city_name"));
            }

            fcity.addActionListener(e->{
                try{
                    mydbcon c2 = new mydbcon();
                    String city2 = (String) fcity.getSelectedItem();
                    ResultSet s1 =  c2.s.executeQuery("select * from city inner join state on city.stateid = state.state_id inner join country on city.countryid = country.country_id where city_name='"+city2+"'");
                    while(s1.next()){
                        fstate.setText(s1.getString("state_name"));
                        fcountry.setText(s1.getString("country_name"));
                    }
                }catch(Exception ex){
                    ex.printStackTrace();
                }
            });


        }catch(Exception e){
            e.printStackTrace();
        }

        String[] tableheading = {"Class", "College", "Obtain", "Total" , "%"};

        String[][] coldata = {
           { "", "", "", "", ""},
            { "", "", "", "", ""},
             { "", "", "", "", ""}
        };


        table = new JTable(coldata, tableheading);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(100, 600, 900  , 100);
        add(sp);

        table.getModel().addTableModelListener(e -> {
        int row = e.getFirstRow();
        int col = e.getColumn();

   
        if (col == 2 || col == 3) {
        try {
            Object ob1 = table.getValueAt(row, 2); // Obtain
            Object ob2 = table.getValueAt(row, 3); // Total

            float obtain = 0, total = 0;

            if (ob1 != null && !ob1.toString().isEmpty())
                obtain = Float.parseFloat(ob1.toString().trim());

            if (ob2 != null && !ob2.toString().isEmpty())
                total = Float.parseFloat(ob2.toString().trim());

            float percent = 0;
            if (obtain < total ) {
                percent = (obtain / total) * 100;
            }else{
                total =0;
            }

            table.setValueAt(String.format("%.2f", percent), row, 4);

          } catch (Exception ex) {
            ex.printStackTrace();
         }
       }
        });
        
        submit = new JButton("summit");
        submit.addActionListener(this);
        submit.setBounds(350, 700, 100  , 50);
        add(submit);

        edit = new JButton("Update");
        edit.addActionListener(this);
        edit.setVisible(false);
        edit.setBounds(450, 700, 100  , 50);
        add(edit);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e){
        mydbcon cc3 = new mydbcon();

        if(e.getSource() == submit){
            if (!validateForm()) return;
            String name = fname.getText();
            String dob = ((JTextField)fdob.getDateEditor().getUiComponent()).getText();
            String doj = ((JTextField)fdoj.getDateEditor().getUiComponent()).getText();
            String mob = fmob.getText();
            String address = faddress.getText();
            String city = (String) fcity.getSelectedItem();

            try{
        
              String query = "Insert Into employee(emp_name,dob,doj,mobile,address,cityid)"+
                "values('"+name+"','"+dob+"','"+doj+"','"+mob+"','"+address+"',(select city_id from city where city_name='"+city+"'))";
                cc3.s.executeUpdate(query);

                ResultSet rs1 = cc3.s.executeQuery("select emp_id from employee where emp_name= '"+name+"'" );
                int empId =0;
                while(rs1.next()){
                    empId = rs1.getInt("emp_id");
                }

                for(int i =0;i<3;i++){

                    String clas = (String) table.getValueAt(i, 0);
                    String college = (String) table.getValueAt(i, 1);
                     Object ob1 = table.getValueAt(i, 2);
                    Object ob2 = table.getValueAt(i, 3);
                    
                    float obtain = 0, total = 0;
                    if (ob1 != null && !ob1.toString().isEmpty())
                            obtain = Float.parseFloat(ob1.toString());
                    if (ob2 != null && !ob2.toString().isEmpty())
                            total = Float.parseFloat(ob2.toString());
                
                    String query2 = "insert into education(class, college, obtain, total, empid)"+
                    "values('"+clas+"', '"+college+"', '"+obtain+"', '"+total+"', "+empId+")";
                    cc3.s.executeUpdate(query2);
                }
                JOptionPane.showMessageDialog(null, "Employee Details Added Successfully");
                setVisible(false);
                new AddForm();
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
        else if (e.getSource()== details){
            new ShowForm();
            this.setVisible(false);
        }
        else if (e.getSource()== edit){
            
            String name = fname.getText();
            String dob = ((JTextField)fdob.getDateEditor().getUiComponent()).getText();
            String doj = ((JTextField)fdoj.getDateEditor().getUiComponent()).getText();
            String mob = fmob.getText();
            String address = faddress.getText();
            String city = (String) fcity.getSelectedItem();

            try{
        
              String query = "Update employee set emp_name='"+name+"', dob='"+dob+"', doj='"+doj+"', mobile='"+mob+"', address='"+address+"', cityid=(select city_id from city where city_name='"+city+"')"+
              " where emp_id='"+editEmpId+"'";
                cc3.s.executeUpdate(query);

                cc3.s.executeUpdate("DELETE FROM education WHERE empid=" + editEmpId);
                for(int i =0;i<3;i++){

                    String clas = (String) table.getValueAt(i, 0);
                    String college = (String) table.getValueAt(i, 1);
                     Object ob1 = table.getValueAt(i, 2);
                    Object ob2 = table.getValueAt(i, 3);
                    
                    float obtain = 0, total = 0;
                    if (ob1 != null && !ob1.toString().isEmpty())
                            obtain = Float.parseFloat(ob1.toString());
                    if (ob2 != null && !ob2.toString().isEmpty())
                            total = Float.parseFloat(ob2.toString());
                    // Float obtain = Float.parseFloat(table.getValueAt(i, 2).toString());
                    // Float total = Float.parseFloat(table.getValueAt(i, 3).toString());

                    String query2 = "insert into education(class, college, obtain, total, empid)"+
                    "values('"+clas+"', '"+college+"', '"+obtain+"', '"+total+"', "+editEmpId+")";
                    cc3.s.executeUpdate(query2);
                }
                JOptionPane.showMessageDialog(null, "Employee Details Added Successfully");
                setVisible(false);
                new AddForm();
            }catch(Exception ex){
                ex.printStackTrace();
            }

            this.setVisible(false);
        }
    }

    public static void main(String[] args) {
        new AddForm();
    }
    
}
