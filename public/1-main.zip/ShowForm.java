import javax.swing.*;

import net.proteanit.sql.DbUtils;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;



public class ShowForm extends JFrame implements ActionListener{
     JLabel heading, ldelete; 
    Choice cname,cid;
    JTable table;
    JButton create, search, delete, edit, read;

    public ShowForm() {
         setSize(900,900);
        setLayout(null);

        create = new JButton("Add Student");
        create.setBounds(10,20,200,20);
        create.addActionListener(this);
        add(create);

        heading = new JLabel("Search By Name");
        heading.setBounds(300, 20, 100, 20);
        add(heading);

        cname = new Choice();
        cname.setBounds(400, 20, 150, 20);  
        add(cname); 

        try{
            mydbcon c1 = new mydbcon();
            ResultSet rs = c1.s.executeQuery("select emp_name from employee");
            while(rs.next()){
                cname.add(rs.getString("emp_name"));
            }
        }catch(Exception e){
            e.printStackTrace();
        }


         search = new JButton("Search");
        search.setBounds(600, 20, 80, 20);
        search.addActionListener(this);
        add(search);

        ldelete  = new JLabel("Read/Delete/Update By ID");
        ldelete.setBounds(10, 70, 150, 20);
        add(ldelete);

        cid = new Choice();
        cid.setBounds(200, 70, 150, 20);
        add(cid);

        try{
            mydbcon c1 = new mydbcon();
            ResultSet rs = c1.s.executeQuery("select emp_id from employee");
            while(rs.next()){
                cid.add(rs.getString("emp_id"));
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        read = new JButton("Read");
        read.setBounds(400, 70, 80, 20);
        read.addActionListener(this);
        add(read);

        delete = new JButton("Delete");
        delete.setBounds(500, 70, 80, 20);
        delete.addActionListener(this);
        add(delete);

        edit = new JButton("Update");
        edit.setBounds(600, 70, 80, 20);
        edit.addActionListener(this);
        add(edit);

        table = new JTable();
        try{
            mydbcon c1 = new mydbcon();
            ResultSet rs1 = c1.s.executeQuery("select * from employee");
            table.setModel(DbUtils.resultSetToTableModel(rs1));

        }catch(Exception e){
            e.printStackTrace();
        }
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(0, 100, 800, 200);
        add(sp);

        

         setVisible(true);

    }

    public void actionPerformed(ActionEvent e){
       mydbcon c1 = new mydbcon();
        if(e.getSource() == create)   {
            new AddForm();
            this.setVisible(false);
        }
        else if(e.getSource() == search){
            try{
             
           ResultSet rs = c1.s.executeQuery("select * from employee where emp_name='"+cname.getSelectedItem()+"'"); 
           table.setModel(DbUtils.resultSetToTableModel(rs));
            }catch(Exception ex){
                ex.printStackTrace();
             }
        }
        else if(e.getSource() == delete){
            try{
                c1.s.execute("delete from education where empid= '"+cid.getSelectedItem()+"'");
                c1.s.executeUpdate("delete from employee where emp_id='"+cid.getSelectedItem()+"'");
                JOptionPane.showMessageDialog(null, "Employee Deleted Successfully");
                ResultSet rs3 = c1.s.executeQuery("select * from employee");
                
                ResultSet rs4 = c1.s.executeQuery("select emp_id from employee");
                while(rs4.next()){
                    cid.add(rs4.getString("emp_id"));
                }
                ResultSet rs5 = c1.s.executeQuery("select emp_name from employee");
                while(rs5.next()){
                    cname.add(rs5.getString("emp_name"));
                }
                table.setModel(DbUtils.resultSetToTableModel(rs3));

            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
        else if(e.getSource() == read){
            new AddForm(Integer.parseInt(cid.getSelectedItem()), "read");
        }
        else if(e.getSource() == edit){
            new AddForm(Integer.parseInt(cid.getSelectedItem()), "edit");
            // this.setVisible(false);
        }
        
    }

    public static void main(String[] args) {
        new ShowForm();
    }
    
}
